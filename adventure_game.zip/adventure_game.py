import time
import random

creature = ["dragon", "wolf", "lion", "a strong  wizard"]


def print_pause(message_to_print):
    print(message_to_print)
    time.sleep(2)

def intro():    
    print("You find yourself standing in an open field,")
    time.sleep(2)
    print("filled with grass and yellow wildflowers.")
    time.sleep(2)
    print("Rumor has it that a wicked fairie is somewhere around here, and has been terrifying the nearby village.")
    time.sleep(2)

def house(item):
    print_pause("Door open and you are welcomed by an old witch")
    print_pause("who is ready to use you as an ingredent in her potion ")
    if 1 in item:
        print_pause(" you use one of the spell in the book to turn your self into a ramdon creature")
        fight = random.choice(creature)
        print(fight)
        print_pause("after changing into the" + "  " + fight + "  " + "you defected the old witch")
    else:    
        print_pause("because you haven't gotten the book of spell, you run away on seeing the old witch")
        item.append(1)
    print_pause("you head back to the open field")    
    run_or_stay(item)
    end_game(item)
    
def cave(item):
    print_pause("you stand in front of a dark cave")
    print_pause("inside the cave there is a book of spells that conains ways to defect the old powerful witch.")
    if 2 in item:
        print_pause("you have picked the book of spells already")
    else:    
        print_pause("you walk towards the bright light shinig inside the cave ")
        print_pause("Then bent down to pick up the old book of spells")
        item.append(2)
    print_pause("go back to the field and open the door.")
    start_over(item)

def exit():
    print_pause("BYE!!!")

def end_game(item):
    print_pause("Will you like to play again?")
    answer = input("Enter Y/N for yes or no:  ")
    
    if answer == 'y':
        print_pause("It will be nice to have you back")
        start_over(item)
    elif answer == 'n':
        print_pause("so sad you are leaving ")
        print_pause("we hope o see you again")
        exit()
    else:
        print_pause("incorrect input")
        end_game(item)
        


def start_over(item):    
    print_pause("Enter 1 to knock on the door of the house. ")
    print_pause("Enter 2 to peer into the cave. ")
    print_pause("What would you like to do? ")
    response = input("(Please enter 1 or 2).  ")
    
    if response == '1':
        house(item)
    elif response == '2':
        cave(item) 
    else:
        print_pause("I don't seems to find this option,Try Again")
        start_over(item)
        
def run_or_stay(item):
    print_pause("will you like to fight?")
    print_pause("if yes enter 'yes' for no enter 'no'")
    choice=input("pick one" + ":" + " ")
    
    if choice == 'yes':
        fight=random.choice(creature)
        print(fight)
        start_over(item)
        cave(item)
    elif choice ==  'no':
        end_game(item)
    else:
        print_pause("Let's try that again")
        run_or_stay(item)    
            
               
    
def play_game():
    item = []
    intro()
    start_over(item)
    end_game(item)
    run_or_stay(item)
    exit()
   

    
play_game()
     
    
    
    